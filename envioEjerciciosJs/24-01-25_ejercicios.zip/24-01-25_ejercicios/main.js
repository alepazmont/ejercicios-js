const passwordInput = document.querySelector('#password');
const passwordRequirements = document.querySelector('#passwordRequirements');

passwordInput.addEventListener('focus', () => {
    passwordRequirements.classList.remove('hidden');
});

passwordInput.addEventListener('blur', () => {
    passwordRequirements.classList.add('hidden');
});

// ☑ 

