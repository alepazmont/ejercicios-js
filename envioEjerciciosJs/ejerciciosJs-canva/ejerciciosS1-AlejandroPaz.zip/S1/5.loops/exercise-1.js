/* Crea un bucle for que vaya desde 0 a 9 y muestralo por consola. */

for (let i = 0 ; i < 10 ; i++) {
    console.log(i)
}