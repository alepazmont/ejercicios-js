/* Multiplica 10 por 5 y muestra el resultado mediante alert. */

let mult = 10 * 5;

window.alert(mult)