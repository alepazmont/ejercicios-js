/* Divide 10 por 2 y muestra el resultado en un alert. */

let div = 10 / 2;

window.alert(div)