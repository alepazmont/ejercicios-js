/* Muestra mediante un alert el resto de dividir 15 por 9 */

let div = 15 / 9

alert(div)