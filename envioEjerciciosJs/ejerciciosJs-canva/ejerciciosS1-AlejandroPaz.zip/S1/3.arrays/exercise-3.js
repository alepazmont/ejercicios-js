/* Alerta el numero de elementos en el array usando la propiedad correcta de Array. */


const cars = ["Saab", "Volvo", "BMW"];

alert(cars.length)