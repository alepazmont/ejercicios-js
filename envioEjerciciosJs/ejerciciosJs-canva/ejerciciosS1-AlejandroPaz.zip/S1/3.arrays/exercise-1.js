/* Consigue el valor "Volvo" del array de cars y muestralo por consola. */

const cars = ["Saab", "Volvo", "BMW"];

var selectCar = cars[1]

console.log(selectCar)