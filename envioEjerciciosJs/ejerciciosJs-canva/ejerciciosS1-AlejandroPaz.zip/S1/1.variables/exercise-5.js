/* Declara 3 variables con los nombres y valores siguientes ``firstName = 'Jon'; lastName = 'Snow'; age = 24``; 
Muestralos por consola de esta forma: Soy Jon Snow, Tengo 24 años y me gustan los lobos.
 */

firstName = 'Jon'; 
lastName = 'Snow'; 
age = 24

console.log(`Soy ${firstName} ${lastName}, Tengo ${age} años y me gustan los lobos.`)