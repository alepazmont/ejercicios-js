/* Crea una variable llamada carName, asignale el valor Volvo a ella.
 */

let carName = "Volvo"

console.log(carName)