/* Crea una variable llamada x con el valor 5 y otra y con el valor 10. Crea una tercera variable z y asignale el valor de x + y. */

const x = 5;
const y = 10;
const z = x + y;

console.log(z);