/* Dado el siguiente html usa querySelector para mostrar por consola el 
botón con la clase .showme*/

let button = document.querySelector("button.showme")

console.log(button)