/* Dado el siguiente html usa querySelector para mostrar por consola el 
3 personaje con el atributo data-function="testMe". */

let span3 = document.querySelector('[data-function="testMe"]:nth-child(3)')

console.log(span3); 