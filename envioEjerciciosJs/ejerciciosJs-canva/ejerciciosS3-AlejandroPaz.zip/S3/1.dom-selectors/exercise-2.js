/* Dado el siguiente html usa querySelector para mostrar por consola el p con 
el id #pillado*/

let pPillado = document.querySelector("p#pillado")

console.log(pPillado)