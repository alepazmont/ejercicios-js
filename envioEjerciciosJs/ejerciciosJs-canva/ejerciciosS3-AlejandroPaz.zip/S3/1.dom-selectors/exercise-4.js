/* Dado el siguiente html usa querySelector para mostrar por consola todos 
los elementos con la clase .pokemon */

const classItems = document.querySelectorAll(".pokemon");

for (let classItem of classItems) {
console.log(classItem)
}