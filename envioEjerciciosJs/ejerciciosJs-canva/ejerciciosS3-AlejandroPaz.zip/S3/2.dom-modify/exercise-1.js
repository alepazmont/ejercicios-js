/* Inserta dinamicamente en un html un div vacio con javascript. */

const div = document.createElement("div");
document.body.append(div);
