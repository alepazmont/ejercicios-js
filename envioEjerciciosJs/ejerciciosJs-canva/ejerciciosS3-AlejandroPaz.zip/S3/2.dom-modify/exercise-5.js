/* Basandote en el siguiente html, inserta en el h2 con la clase 
.fn-insert-here el texto 'Wubba Lubba dub dub'. */

const h2 = document.querySelector("h2.fn-insert-here")


h2.textContent += "Wubba Lubba dub dub";
